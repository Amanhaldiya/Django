# django-todo-app
A Smple Todo App developed by Django Framework
